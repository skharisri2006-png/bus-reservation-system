﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Bus_Reservation
{
    public partial class Seats : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void Seat_Click(object sender, EventArgs e)
        {
            Button selectedButton = (Button)sender;

            string seatNumber = selectedButton.Text;

            Session["SelectedSeat"] = seatNumber;
            Session["SeatNumber"] = seatNumber;

            lblSelected.Text =
                "Selected Seat: " + seatNumber;
        }

        protected void btnContinue_Click(object sender, EventArgs e)
        {
            if (Session["SelectedSeat"] == null)
            {
                lblSelected.Text =
                    "Please select a seat first.";

                return;
            }

            Response.Redirect("Payment.aspx");
        }
    }
}