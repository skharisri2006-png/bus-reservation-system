﻿using System;

namespace Bus_Reservation
{
    public partial class Passenger : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblMessage.Text = "";
            }
        }

        protected void btnContinue_Click(object sender, EventArgs e)
        {
            string name = txtPassengerName.Text.Trim();
            string phone = txtPhone.Text.Trim();
            string email = txtEmail.Text.Trim();

            if (string.IsNullOrWhiteSpace(name))
            {
                lblMessage.Text = "Please enter passenger name.";
                return;
            }

            if (string.IsNullOrWhiteSpace(phone))
            {
                lblMessage.Text = "Please enter phone number.";
                return;
            }

            if (string.IsNullOrWhiteSpace(email))
            {
                lblMessage.Text = "Please enter email.";
                return;
            }

            Session["PassengerName"] = name;
            Session["Phone"] = phone;
            Session["Email"] = email;

            Response.Redirect("SeatSelection.aspx");
        }
    }
}