﻿<%@ Page Language="C#" AutoEventWireup="true"
    CodeBehind="Passenger.aspx.cs"
    Inherits="Bus_Reservation.Passenger" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Passenger Details</title>

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f6f8;
        }

        .passenger-container {
            width: 450px;
            max-width: 90%;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }

        h2 {
            text-align: center;
            color: #1456d8;
            margin-bottom: 25px;
        }

        .label {
            display: block;
            margin-bottom: 7px;
            font-weight: bold;
        }

        .input {
            width: 100%;
            padding: 12px;
            margin-bottom: 18px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 7px;
        }

        .btn {
            width: 100%;
            padding: 13px;
            background: #1456d8;
            color: white;
            border: none;
            border-radius: 7px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
        }

        .message {
            display: block;
            margin-bottom: 15px;
            text-align: center;
            font-weight: bold;
        }
    </style>
</head>

<body>

<form id="form1" runat="server">

    <div class="passenger-container">

        <h2>Passenger Details</h2>

        <asp:Label
            ID="lblMessage"
            runat="server"
            CssClass="message">
        </asp:Label>

        <asp:Label
            ID="lblPassengerName"
            runat="server"
            Text="Passenger Name"
            CssClass="label">
        </asp:Label>

        <asp:TextBox
            ID="txtPassengerName"
            runat="server"
            CssClass="input">
        </asp:TextBox>

        <asp:Label
            ID="lblPhone"
            runat="server"
            Text="Phone Number"
            CssClass="label">
        </asp:Label>

        <asp:TextBox
            ID="txtPhone"
            runat="server"
            CssClass="input"
            TextMode="Phone">
        </asp:TextBox>

        <asp:Label
            ID="lblEmail"
            runat="server"
            Text="Email"
            CssClass="label">
        </asp:Label>

        <asp:TextBox
            ID="txtEmail"
            runat="server"
            CssClass="input"
            TextMode="Email">
        </asp:TextBox>

        <asp:Button
            ID="btnContinue"
            runat="server"
            Text="Continue to Seat Selection"
            CssClass="btn"
            OnClick="btnContinue_Click" />

    </div>

</form>

</body>
</html>