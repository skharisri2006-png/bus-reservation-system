﻿using System;

namespace BusReservationSystem
{
    public partial class Register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            string email = txtEmail.Text.Trim();
            string password = txtPassword.Text;

            if (string.IsNullOrWhiteSpace(name))
            {
                lblMessage.Text = "Please enter your name.";
                return;
            }

            if (string.IsNullOrWhiteSpace(email))
            {
                lblMessage.Text = "Please enter your email.";
                return;
            }

            if (string.IsNullOrWhiteSpace(password))
            {
                lblMessage.Text = "Please enter your password.";
                return;
            }

            Session["UserName"] = name;
            Session["UserEmail"] = email;

            lblMessage.Text =
                "Registration successful. You can login now.";
        }
    }
}