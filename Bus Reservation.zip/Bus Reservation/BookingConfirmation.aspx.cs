﻿using System;

namespace BusReservationSystem
{
    public partial class BookingConfirmation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string from = Convert.ToString(Session["From"]);
                string to = Convert.ToString(Session["To"]);
                string date = Convert.ToString(Session["Journey Date"]);
                string passenger = Convert.ToString(Session["PassengerName"]);
                string seat = Convert.ToString(Session["SeatNumber"]);
                string payment = Convert.ToString(Session["PaymentStatus"]);

                lblBooking.Text =
                    "Passenger: " + passenger +
                    "<br/>From: " + from +
                    "<br/>To: " + to +
                    "<br/>Journey Date: " + date +
                    "<br/>Seat Number: " + seat +
                    "<br/>Payment Status: " + payment;
            }
        }
    }
}