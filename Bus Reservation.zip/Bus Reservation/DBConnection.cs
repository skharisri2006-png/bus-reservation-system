﻿using System.Configuration;
using System.Data.SqlClient;

namespace BusReservationSystem
{
    public class DBConnection
    {
        private static readonly string connectionString =
            ConfigurationManager
            .ConnectionStrings["BusReservationDB"]
            .ConnectionString;

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }
    }
}
