﻿<%@ Page Language="C#" AutoEventWireup="true"
    CodeBehind="Home.aspx.cs"
    Inherits="BusReservationSystem.Home" %>

<!DOCTYPE html>

<html>
<head runat="server">
    <title>Bus Reservation System</title>
    <link href="CSS/style.css" rel="stylesheet" />
</head>

<body>

<form id="form1" runat="server">

    <nav class="navbar">

        <div class="logo">
            🚌 BusGo
        </div>

        <nav>
            <a href="Home.aspx">Home</a>
            <a href="SearchBus.aspx">Search</a>
            <a href="Passenger.aspx">Passenger</a>
            <a href="SeatSelection.aspx">Seats</a>
            <a href="Payment.aspx">Payment</a>
            <a href="BookingConfirmation.aspx">Booking</a>
            <a href="Login.aspx">Login</a>
            <a href="Register.aspx">Register</a>
        </nav>

        <a href="SearchBus.aspx" class="Search-btn">
            Search Bus
        </a>

    </nav>

    <section class="home-page">

        <div class="home-content">

            <h1>Travel Smart. Travel Easy.</h1>

            <p>
                Book your bus tickets quickly and safely
                with our modern bus reservation system.
            </p>

            <a href="SearchBus.aspx" class="primary-btn">
                Search & Book Bus
            </a>

        </div>

    </section>

</form>

</body>
</html>