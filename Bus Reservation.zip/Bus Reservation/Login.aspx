﻿<%@ Page Title="Login"
    Language="C#"
    MasterPageFile="~/Site.Master"
    AutoEventWireup="true"
    CodeBehind="Login.aspx.cs"
    Inherits="BusReservationSystem.Login" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="MainContent"
    runat="server">

    <div class="page-container">

        <div class="card">

            <h1>Login</h1>

            <div class="form-group">

                <label>Email</label>

                <asp:TextBox
                    ID="txtEmail"
                    runat="server"
                    CssClass="form-control">
                </asp:TextBox>

            </div>

            <div class="form-group">

                <label>Password</label>

                <asp:TextBox
                    ID="txtPassword"
                    runat="server"
                    TextMode="Password"
                    CssClass="form-control">
                </asp:TextBox>

            </div>

            <asp:Button
                ID="btnLogin"
                runat="server"
                Text="Login"
                CssClass="primary-btn"
                OnClick="btnLogin_Click" />

            <asp:Label
                ID="lblMessage"
                runat="server"
                CssClass="message">
            </asp:Label>

        </div>

    </div>

</asp:Content>