﻿<%@ Page Title="Booking"
    Language="C#"
    MasterPageFile="~/Site.Master"
    AutoEventWireup="true"
    CodeBehind="BookingConfirmation.aspx.cs"
    Inherits="BusReservationSystem.BookingConfirmation" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="MainContent"
    runat="server">

    <div class="page-container">

        <div class="card">

            <h1>Booking Confirmed</h1>

            <p>
                Your bus booking has been completed successfully.
            </p>

            <asp:Label
                ID="lblBooking"
                runat="server"
                CssClass="message">
            </asp:Label>

            <br />

            <a href="Default.aspx"
               class="start-btn">
                Back to Home
            </a>

        </div>

    </div>

</asp:Content>