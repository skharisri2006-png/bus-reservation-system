﻿<%@ Page Language="C#" AutoEventWireup="true"
    CodeBehind="TestConnection.aspx.cs"
    Inherits="BusReservationSystem.TestConnection" %>

<!DOCTYPE html>

<html>
<head runat="server">
    <title>Database Connection Test</title>
</head>

<body>

<form id="form1" runat="server">

    <div>

        <h2>Bus Reservation Database Test</h2>

        <asp:Label
            ID="lblMessage"
            runat="server">
        </asp:Label>

    </div>

</form>

</body>
</html>