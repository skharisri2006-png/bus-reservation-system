﻿<%@ Page Title="Home"
    Language="C#"
    MasterPageFile="~/Site.Master"
    AutoEventWireup="true"
    CodeBehind="Default.aspx.cs"
    Inherits="BusReservationSystem._Default" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="MainContent"
    runat="server">

    <div class="home-container">

        <img src="Images/bus-left.jpg"
             class="bus-left"
             alt="Bus" />

        <img src="Images/bus-right.jpg"
             class="bus-right"
             alt="Bus" />

        <div class="home-content">

            <h1>Welcome to Our</h1>

            <h2>Bus Reservation System</h2>

            <p>
                Book your bus ticket easily,
                quickly and securely.
            </p>

            <a href="SearchBus.aspx"
               class="start-btn">
                Search Bus
            </a>

        </div>

    </div>

</asp:Content>