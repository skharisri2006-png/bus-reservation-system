﻿<%@ Page Language="C#" AutoEventWireup="true"
    CodeBehind="SearchBus.aspx.cs"
    Inherits="Bus_Reservation.Search" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Search Bus</title>

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f2f6ff;
        }

        .search-container {
            width: 500px;
            max-width: 90%;
            margin: 70px auto;
            background: white;
            padding: 35px;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }

        .search-container h1 {
            text-align: center;
            color: #1456d8;
            margin-bottom: 25px;
        }

        .input {
            width: 100%;
            padding: 13px;
            margin-bottom: 15px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 7px;
            font-size: 15px;
        }

        .input:focus {
            outline: none;
            border-color: #1456d8;
        }

        .search-btn {
            width: 100%;
            padding: 13px;
            background: #1456d8;
            color: white;
            border: none;
            border-radius: 7px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
        }

        .search-btn:hover {
            background: #0d3fa5;
        }

        .message {
            display: block;
            margin-top: 20px;
            text-align: center;
            font-weight: bold;
        }
    </style>
</head>

<body>

<form id="form1" runat="server">

    <div class="search-container">

        <h1>Search Bus</h1>

        <asp:TextBox
            ID="txtFrom"
            runat="server"
            CssClass="input"
            placeholder="From">
        </asp:TextBox>

        <asp:TextBox
            ID="txtTo"
            runat="server"
            CssClass="input"
            placeholder="To">
        </asp:TextBox>

        <asp:TextBox
            ID="txtDate"
            runat="server"
            CssClass="input"
            TextMode="Date">
        </asp:TextBox>

        <asp:Button
            ID="btnSearch"
            runat="server"
            Text="Search Bus"
            CssClass="search-btn"
            OnClick="btnSearch_Click" />

        <asp:Label
            ID="lblMessage"
            runat="server"
            CssClass="message">
        </asp:Label>

    </div>

</form>

</body>
</html>