﻿using System;
using System.Data.SqlClient;

namespace BusReservationSystem
{
    public partial class TestConnection : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                TestDatabase();
            }
        }

        private void TestDatabase()
        {
            try
            {
                using (SqlConnection con = DBConnection.GetConnection())
                {
                    con.Open();

                    lblMessage.Text =
                        "Database Connected Successfully!";

                    lblMessage.CssClass = "success";
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text =
                    "Database Connection Failed.<br/><br/>" +
                    ex.Message;

                lblMessage.CssClass = "error";
            }
        }
    }
}