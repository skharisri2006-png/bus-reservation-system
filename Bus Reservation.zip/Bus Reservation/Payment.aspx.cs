﻿using System;

namespace Bus_Reservation
{
    public partial class Payment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadPaymentData();
            }
        }

        private void LoadPaymentData()
        {
            if (Session["SelectedSeat"] != null)
            {
                lblSeat.Text = Session["SelectedSeat"].ToString();
            }
            else
            {
                lblSeat.Text = "Not Selected";
            }

            if (Session["Amount"] != null)
            {
                txtAmount.Text = Session["Amount"].ToString();
            }
            else
            {
                txtAmount.Text = "500";
                Session["Amount"] = "500";
            }
        }

        protected void btnPay_Click(object sender, EventArgs e)
        {
            if (ddlPayment.SelectedValue == "")
            {
                lblMessage.Text =
                    "Please select a payment method.";
                return;
            }

            if (Session["SelectedSeat"] == null)
            {
                lblMessage.Text =
                    "Please select a seat.";
                return;
            }

            Session["PaymentMethod"] =
                ddlPayment.SelectedValue;

            Session["PaymentAmount"] =
                txtAmount.Text;

            lblMessage.Text =
                "Payment successful using " +
                ddlPayment.SelectedValue +
                ".";
        }
    }
}