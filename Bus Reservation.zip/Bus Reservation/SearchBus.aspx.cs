﻿using System;

namespace Bus_Reservation
{
    public partial class Search : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            string from = txtFrom.Text.Trim();
            string to = txtTo.Text.Trim();
            string date = txtDate.Text.Trim();

            if (string.IsNullOrWhiteSpace(from))
            {
                lblMessage.Text = "Please enter From location.";
                return;
            }

            if (string.IsNullOrWhiteSpace(to))
            {
                lblMessage.Text = "Please enter To location.";
                return;
            }

            if (string.IsNullOrWhiteSpace(date))
            {
                lblMessage.Text = "Please select journey date.";
                return;
            }

            Session["From"] = from;
            Session["To"] = to;
            Session["JourneyDate"] = date;

            lblMessage.Text =
                "Buses available from " + from +
                " to " + to +
                " on " + date + ".";
        }
    }
}