﻿<%@ Page Language="C#" AutoEventWireup="true"
    CodeBehind="SeatSelection.aspx.cs"
    Inherits="Bus_Reservation.Seats" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Seat Selection</title>

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f2f6ff;
        }

        .seat-container {
            width: 600px;
            max-width: 90%;
            margin: 45px auto;
            background: white;
            padding: 35px;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
            text-align: center;
        }

        h1 {
            color: #1456d8;
        }

        .seats-grid {
            display: grid;
            grid-template-columns: repeat(4, 70px);
            gap: 18px;
            justify-content: center;
            margin: 30px 0;
        }

        .seat {
            height: 55px;
            background: #d8eaff;
            border: 2px solid #1456d8;
            border-radius: 8px;
            color: #1456d8;
            font-weight: bold;
            cursor: pointer;
        }

        .seat:hover {
            background: #1456d8;
            color: white;
        }

        .message {
            display: block;
            margin: 20px;
            font-weight: bold;
        }

        .continue-btn {
            width: 100%;
            padding: 13px;
            background: #1456d8;
            color: white;
            border: none;
            border-radius: 7px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }
    </style>
</head>

<body>

<form id="form1" runat="server">

    <div class="seat-container">

        <h1>Select Your Seat</h1>

        <p>Choose one seat for your journey.</p>

        <div class="seats-grid">

            <asp:Button ID="btnSeat1" runat="server"
                Text="1" CssClass="seat"
                OnClick="Seat_Click" />

            <asp:Button ID="btnSeat2" runat="server"
                Text="2" CssClass="seat"
                OnClick="Seat_Click" />

            <asp:Button ID="btnSeat3" runat="server"
                Text="3" CssClass="seat"
                OnClick="Seat_Click" />

            <asp:Button ID="btnSeat4" runat="server"
                Text="4" CssClass="seat"
                OnClick="Seat_Click" />

            <asp:Button ID="btnSeat5" runat="server"
                Text="5" CssClass="seat"
                OnClick="Seat_Click" />

            <asp:Button ID="btnSeat6" runat="server"
                Text="6" CssClass="seat"
                OnClick="Seat_Click" />

            <asp:Button ID="btnSeat7" runat="server"
                Text="7" CssClass="seat"
                OnClick="Seat_Click" />

            <asp:Button ID="btnSeat8" runat="server"
                Text="8" CssClass="seat"
                OnClick="Seat_Click" />

        </div>

        <asp:Label
            ID="lblSelected"
            runat="server"
            CssClass="message">
        </asp:Label>

        <asp:Button
            ID="btnContinue"
            runat="server"
            Text="Continue to Payment"
            CssClass="continue-btn"
            OnClick="btnContinue_Click" />

    </div>

</form>

</body>
</html>