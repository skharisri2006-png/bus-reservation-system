using System.Web.Routing;

namespace Bus_Reservation
{
    public static class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            // Friendly URLs disabled.
            // Use normal .aspx pages.
        }
    }
}
