﻿<%@ Page Title="Register"
    Language="C#"
    MasterPageFile="~/Site.Master"
    AutoEventWireup="true"
    CodeBehind="Register.aspx.cs"
    Inherits="BusReservationSystem.Register" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="MainContent"
    runat="server">

    <div class="page-container">

        <div class="card">

            <h1>Create Account</h1>

            <div class="form-group">

                <label>Full Name</label>

                <asp:TextBox
                    ID="txtName"
                    runat="server"
                    CssClass="form-control">
                </asp:TextBox>

            </div>

            <div class="form-group">

                <label>Email</label>

                <asp:TextBox
                    ID="txtEmail"
                    runat="server"
                    CssClass="form-control">
                </asp:TextBox>

            </div>

            <div class="form-group">

                <label>Password</label>

                <asp:TextBox
                    ID="txtPassword"
                    runat="server"
                    TextMode="Password"
                    CssClass="form-control">
                </asp:TextBox>

            </div>

            <asp:Button
                ID="btnRegister"
                runat="server"
                Text="Register"
                CssClass="primary-btn"
                OnClick="btnRegister_Click" />

            <asp:Label
                ID="lblMessage"
                runat="server"
                CssClass="message">
            </asp:Label>

        </div>

    </div>

</asp:Content>