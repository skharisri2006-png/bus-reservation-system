﻿<%@ Page Language="C#" AutoEventWireup="true"
    CodeBehind="Payment.aspx.cs"
    Inherits="Bus_Reservation.Payment" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">

<head runat="server">

    <title>Payment - Bus Reservation</title>

    <style>

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #eef6ff;
        }

        .payment-container {
            width: 450px;
            max-width: 90%;
            margin: 60px auto;
            background: white;
            padding: 35px;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }

        .payment-container h1 {
            text-align: center;
            color: #1456d8;
            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .label {
            display: block;
            font-weight: bold;
            margin-bottom: 8px;
            color: #333;
        }

        .input {
            width: 100%;
            padding: 12px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 7px;
            font-size: 15px;
        }

        .select {
            width: 100%;
            padding: 12px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 7px;
            font-size: 15px;
            background: white;
        }

        .pay-button {
            width: 100%;
            padding: 14px;
            background: #1456d8;
            color: white;
            border: none;
            border-radius: 7px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }

        .pay-button:hover {
            background: #0d3fa5;
        }

        .message {
            display: block;
            margin-top: 20px;
            text-align: center;
            font-weight: bold;
            color: #1456d8;
        }

        .seat-box {
            background: #eef6ff;
            padding: 12px;
            border-radius: 7px;
            color: #1456d8;
            font-weight: bold;
        }

    </style>

</head>

<body>

<form id="form1" runat="server">

    <div class="payment-container">

        <h1>Bus Reservation Payment</h1>


        <!-- SELECTED SEAT -->

        <div class="form-group">

            <asp:Label
                ID="lblSeatTitle"
                runat="server"
                Text="Selected Seat"
                CssClass="label">
            </asp:Label>

            <div class="seat-box">

                <asp:Label
                    ID="lblSeat"
                    runat="server"
                    Text="Not Selected">
                </asp:Label>

            </div>

        </div>


        <!-- AMOUNT -->

        <div class="form-group">

            <asp:Label
                ID="lblAmountTitle"
                runat="server"
                Text="Amount"
                CssClass="label">
            </asp:Label>

            <asp:TextBox
                ID="txtAmount"
                runat="server"
                CssClass="input"
                ReadOnly="true">
            </asp:TextBox>

        </div>


        <!-- PAYMENT METHOD -->

        <div class="form-group">

            <asp:Label
                ID="lblPaymentTitle"
                runat="server"
                Text="Payment Method"
                CssClass="label">
            </asp:Label>

            <asp:DropDownList
                ID="ddlPayment"
                runat="server"
                CssClass="select">

                <asp:ListItem
                    Text="-- Select Payment Method --"
                    Value="">
                </asp:ListItem>

                <asp:ListItem
                    Text="UPI"
                    Value="UPI">
                </asp:ListItem>

                <asp:ListItem
                    Text="Credit Card"
                    Value="Credit Card">
                </asp:ListItem>

                <asp:ListItem
                    Text="Debit Card"
                    Value="Debit Card">
                </asp:ListItem>

                <asp:ListItem
                    Text="Net Banking"
                    Value="Net Banking">
                </asp:ListItem>

            </asp:DropDownList>

        </div>


        <!-- PAY BUTTON -->

        <div class="form-group">

            <asp:Button
                ID="btnPay"
                runat="server"
                Text="Pay Now"
                CssClass="pay-button"
                OnClick="btnPay_Click">
            </asp:Button>

        </div>


        <!-- MESSAGE -->

        <asp:Label
            ID="lblMessage"
            runat="server"
            CssClass="message">
        </asp:Label>

    </div>

</form>

</body>

</html>